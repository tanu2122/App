import React from 'react';
import './App.css';
import ShowUsers from './ShowUsers';

function App() {
  return (
    <div className="App">
    <ShowUsers/>
    </div>
  );
}

export default App;
